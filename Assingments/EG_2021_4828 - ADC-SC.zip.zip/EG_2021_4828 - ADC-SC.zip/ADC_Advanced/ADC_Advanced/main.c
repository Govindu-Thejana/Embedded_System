/*
 * ADC_Advanced.c
 *
 * Created: 1/30/2025 11:20:57 PM
 * Author: Govindu
 * Description: Reads an analog value from ADC channel 0 and outputs the 10-bit result
 *              to PORTD (lower 8 bits) and PORTB (upper 2 bits).
 */

#define F_CPU 16000000UL  // Define CPU clock frequency for delay functions

#include <avr/io.h>       // Include AVR I/O definitions
#include <util/delay.h>   // Include delay functions

// Function to initialize the ADC
void ADC_Init() {
    ADMUX = (1 << REFS0);  // Set reference voltage to AVCC (5V)
    ADCSRA = (1 << ADEN) | (1 << ADPS2) | (1 << ADPS1) | (1 << ADPS0);  // Enable ADC and set prescaler to 128
}

// Function to read the ADC value from a specific channel
uint16_t ADC_Read(uint8_t channel) {
    ADMUX = (1 << REFS0) | (channel & 0x07);  // Select ADC channel (0�7) and set reference voltage
    ADCSRA |= (1 << ADSC);  // Start ADC conversion
    while (ADCSRA & (1 << ADSC));  // Wait until conversion is complete
    return ADC;  // Return the 10-bit ADC result
}

int main(void) {
    ADC_Init();  // Initialize the ADC

    DDRD = 0xFF;  // Set all pins of PORTD as output (for lower 8 bits of ADC result)
    DDRB |= (1 << PB0) | (1 << PB1);  // Set PB0 and PB1 as output (for upper 2 bits of ADC result)

    while (1) {
        uint16_t adcValue = ADC_Read(0);  // Read the ADC value from channel 0

        // Output the lower 8 bits of the ADC result to PORTD
        PORTD = adcValue & 0xFF;

        // Output the upper 2 bits of the ADC result to PB0 and PB1
        PORTB = (PORTB & 0xFC) | ((adcValue >> 8) & 0x03);

        _delay_ms(10);  // Add a small delay between ADC reads
    }
}